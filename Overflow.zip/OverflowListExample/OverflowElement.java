import java.io.Serializable;

/**
 * Represents an element (node) in an Overflow List.
 * @author Armani Ferrante
 */
public class OverflowElement implements Serializable{

    /**
     * Designated constructor for List Elements.
     * */
    OverflowElement(String head, OverflowElement tail) {
        _head = head;
        _tail = tail;
    }

    /**
     * Conenvience constructor to add on a head with a null tail.
     */
    OverflowElement(String head) {
        this(head, null);
    }

    /** Convenience constructor for a null element. */
    OverflowElement() {
        this(null, null);
    }

    /**
     * Returns the head of this list.
     */
    public String head() {
        return _head;
    }

    /**
     * Returns the tail of this list.
     */
    public OverflowElement tail() {
        return _tail;
    }

    /**
     * Sets HEAD for the head of this entry.
     */
    public void setHead(String head) {
        _head = head;
    }

    /**
     * Sets TAIL for the tail of this entry.
     */
    public void setTail(OverflowElement tail) {
        _tail = tail;
    }

    /**
     * The head of this linked list.
     */
    private String _head;

    /**
     * The tail of this linked list.
     */
    private OverflowElement _tail;
}
