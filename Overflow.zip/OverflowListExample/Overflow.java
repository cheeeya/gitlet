import java.util.Scanner;

/**
 * Entry point into the Overflow program.
 * This file acts as a command interpreter.
 *
 * @author Armani Ferrante
 */

public class Overflow {

    public static void main (String... args) {
        OverflowList overflow = OverflowList.list();

        Scanner inp = new Scanner(System.in);
        int arg2 = convertSecondArgumentToInt(args);

        switch (args[0]) {
        case "print":
            overflow.print();
            break;
        case "resize":
            overflow.resize(arg2);
            break;
        case "add":

            /*
             * Uses the scanner to read input from
             * console, appending the input to the list.
             */

            int n = arg2;
            while (n > 0) {
                overflow.add(inp.next());
                n -= 1;
            }
            break;
        case "remove":
            overflow.remove(arg2);
            break;
        }

        OverflowList.serialWrite(overflow);
    }

    /**
     * Converts second argument, if available, to
     * to an integer.
     */
    private static int convertSecondArgumentToInt(String[] args) {
        if (args.length == 2) {
            try {
                return Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                return -1;
            }
        } else {
            return -1;
        }
    }
}
