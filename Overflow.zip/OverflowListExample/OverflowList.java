import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.File;
import java.io.Serializable;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * A list that can add, remove,
 * and print the contents inside it. This list
 * has a fixed size upon initialization and,
 * once the number of items inside of it are
 * greater than or equal to the size, then the
 * list modularly wraps around, or "overflows",
 * overriding items in the beginning of the list.
 * Implemented as a singly linked list with a
 * sentinel.
 *
 *  @author Armani Ferrante
 */

public class OverflowList implements Serializable {


    ///////////////////////////////////////////////////////////////////
    /**************************** Static *****************************/
    ///////////////////////////////////////////////////////////////////

    /**
     * The path of the file (relative to current directory) of the
     * file where my serial object is store.
     */
    public static final String LIST_PATH = "OverflowList.ser";

    /**
     * The default max capacity of any lis created.
     */
    public static final int DEFAULT_SIZE = 5;

    /**
     * If a OverflowList has been initialized, then
     * retrieves the object from the serial file.
     * Otherwise, creates a brand new OverflowList
     * objects.
     */
    public static OverflowList list() {
        if (isListInitialized()) {
            return serialRead();
        } else {
            return new OverflowList(DEFAULT_SIZE);
        }
    }

    /**
     * Returns true iff a OverflowList has been created
     * and stored in a .ser file.
     */
    private static boolean isListInitialized() {
        File list =  new File(LIST_PATH);
        return list.exists();
    }

    /**
     *  Deserializes a GitletController iff a repo has been
     *  initialized in the current directory and a
     *  GitletController.ser file exists.
     */
    public static OverflowList serialRead()  {
        OverflowList buff = null;
        try {
            ObjectInput input = new ObjectInputStream (
                                new FileInputStream(
                                LIST_PATH));
            try {
                buff = (OverflowList) input.readObject();
            } catch (ClassNotFoundException e2) {
                System.err.printf("Error: %s\n", e2.toString());
            }
        } catch (IOException e) {
            System.err.printf("Error: %s\n", e.toString());
        }
        return buff;
    }

    /**
     *  Serializes LIST, an instance of a OverflowList.
     */
    public static void serialWrite(OverflowList list) {
        try {
            ObjectOutput output = new ObjectOutputStream(
                                  new FileOutputStream(
                                  LIST_PATH));
            output.writeObject(list);
        } catch (IOException e) {
            System.err.printf("Error: %s\n", e.toString());
        }
    }


    ///////////////////////////////////////////////////////////////////
    /************************** Non-Static ***************************/
    ///////////////////////////////////////////////////////////////////


    /**
     * Designated constructor. Initializes the sentinel
     * and MAXSIZE of this list.
     */
    public OverflowList(int maxSize) {
        _sentinel = new OverflowElement(null, new OverflowElement());
        _maxSize = maxSize;
        _next = _sentinel.tail();
        _nextIndex = _currentSize = 0;
    }

    /**
     * Adds an ITEM to the back of me if not full.
     * otherwise overrides an element in the front.
     */
    public void add(String item) {
        if (_nextIndex == _maxSize) {
            startOver(item);
        } else if (_currentSize == _maxSize) {
            override(item);
        } else {
            addToEnd(item);
        }
    }

    /**
     * Adds ITEM to the beginning of the list, starting
     * the list back at the beginning.
     */
    private void startOver(String item) {
        _next = _sentinel.tail();
        _next.setHead(item);
        _next = _next.tail();
        _nextIndex = 1;
    }

    /**
     * Adds ITEM at the next index, overriding
     * what was there previously.
     */
    private void override(String item) {
        _next.setHead(item);
        _next = _next.tail();
        _nextIndex += 1;
    }

    /**
     * Adds ITEM to the end of THIS list. Assumes
     *  _CURRENTSIZE < _MAXSIZE.
     */
    private void addToEnd(String item) {
        _next.setHead(item);
        _next.setTail(new OverflowElement());
        _next = _next.tail();
        _currentSize += 1;
        _nextIndex += 1;
    }

    /**
     * Removes all instances of n from the list.
     */
    public void remove(int n) {
        if (n > _currentSize) {
            return;
        }
        _currentSize -= n;
        while (n > 0) {
            _sentinel.setTail(_sentinel.tail().tail());
            n -= 1;
        }
        _nextIndex = _currentSize;
    }

    /**
     * Prints all the contents of this list.
     */
    public void print() {
        if (_currentSize == 0) {
            System.out.println("No elements to print");
        } else {
            System.out.print("[ ");
            OverflowElement curr = _sentinel.tail();
            while (curr != null && curr.head() != null) {
                System.out.print(curr.head() + " ");
                curr = curr.tail();
            }
            System.out.println("]");
        }
    }

    /**
     * Resizes the max capacity of this overflow list
     * according to NEWSIZE.
     */
    public void resize(int newSize) {
        _sentinel = new OverflowElement(null, new OverflowElement());
        _maxSize = newSize;
        _next = _sentinel.tail();
        _nextIndex = _currentSize = 0;
    }

    /**
     * The sentinel of this list, pointing to
     * the beginning of the linked list of entries
     * inside me.
     */
    private OverflowElement _sentinel;

    /**
     * Points to the place where the next element should be
     * inserted.
     */
    private OverflowElement _next;

    /**
     * The index of the next place to add an element.
     */
    private int _nextIndex;

    /**
     * The maximum amount of items in this list.
     */
    private int _maxSize;

    /**
     * The amount of items currently in me.
     */
    private int _currentSize;
}
